BARAKAT TRAVEL v3 CLEAN

Загрузка в Netlify:
1) Открой Deploys
2) Нажми Upload deploy
3) Загрузи этот ZIP
4) Дождись Published

Внутри:
index.html
beaches.html / hotels.html / mountains.html / forests.html / cities.html
turkey.html
kemer.html / belek.html / side.html / alanya.html / antalya.html

Если Netlify снова покажет ошибку, открой deploy и пришли скрин деталей ошибки.
